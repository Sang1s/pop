package application;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import ValidFields.ValidPosDoubleField;
import ValidFields.ValidPosIntField;
import javafx.beans.property.ReadOnlyDoubleWrapper;
import javafx.beans.property.ReadOnlyIntegerWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.shape.Rectangle;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import stats.LoanStat;
import ValidFields.ValidPosIntField;
import ValidFields.ValidPosDoubleField;

public class MainController {
	
	@FXML
	private Label errorMsg;
	
	@FXML
	private Rectangle saveAsTextErrorOutline;
	
	@FXML
	private TextField loanField;
	@FXML
	private Rectangle loanErrorOutline;
	private static double loanSize = 0;
	private static ValidPosDoubleField loanValidField; 
	
	@FXML
	private TextField termField;
	@FXML
	private Rectangle termErrorOutline;
	private static int loanTerm = 0;
	private static ValidPosIntField termValidField;
	
	@FXML
	private TextField interestField;
	@FXML
	private Rectangle interestErrorOutline;
	private static double interestRate = 0;
	private static ValidPosDoubleField interestValidField;
	
	@FXML
	private RadioButton rMonthlyButton;
	@FXML
	private RadioButton rYearlyButton;
	private static boolean termIsMonthly = true;

	@FXML
	private RadioButton rLinearButton;
	@FXML
	private RadioButton rAnnuityButton;
	static boolean loanIsLinear = true;
	
	@FXML
	private TextField filterMonthFromField;
	@FXML
	private Rectangle monthFromErrorOutline;
	private static int filterMonthFrom = -1;
	private static ValidPosIntField filterFromValidField;
	
	@FXML
	private TextField filterMonthToField;
	@FXML
	private Rectangle monthToErrorOutline;
	private static int filterMonthTo = -1;
	private static ValidPosIntField filterToValidField;
	
	
	@FXML
	private TextField deferFromField;
	@FXML
	private Rectangle deferFromErrorOutline;
	private static int deferFrom = -1;
	private static ValidPosIntField deferFromValidField;
	
	@FXML
	private TextField deferAmountField;
	@FXML
	private Rectangle deferAmountErrorOutline;
	private static int deferAmount= -1;
	private static ValidPosIntField deferAmountValidField;
	
	@FXML
	private TextField deferRateField;
	@FXML
	private Rectangle deferRateErrorOutline;
	private static double deferRate = -1;
	private static ValidPosDoubleField deferRateValidField;
	
	
	private static ObservableList<LoanStat> loanList;
	
	@FXML
	private TableView<LoanStat> loanTable;
	
	@FXML
	private TableColumn<LoanStat, Integer> monthColumn;
	@FXML
	private TableColumn<LoanStat, Double> interestColumn;
	@FXML
	private TableColumn<LoanStat, Double> principalColumn;
	@FXML
	private TableColumn<LoanStat, Double> remainingColumn;
	
	
	private Parent chartRoot;
	private FXMLLoader chartLoader;
	
	static Series<Number, Number> series;
	
	
	@FXML
	private void initialize() throws IOException {
		if (!termIsMonthly) {
			rYearlyButton.setSelected(true);
		}
		if (!loanIsLinear) {
			rAnnuityButton.setSelected(true);
		}
		if (filterMonthFrom != -1) {
			filterMonthFromField.setText(Integer.toString(filterMonthFrom));
		}
		if (filterMonthTo != -1) {
			filterMonthToField.setText(Integer.toString(filterMonthTo));
		}
		if (deferFrom != -1) {
			deferFromField.setText(Integer.toString(deferFrom));
		}
		if (deferAmount != -1) {
			deferAmountField.setText(Integer.toString(deferAmount));
		}
		if (deferRate != -1) {
			deferRateField.setText(Double.toString(deferRate));
		}
		monthColumn.setCellValueFactory(new PropertyValueFactory<>("month"));
		interestColumn.setCellValueFactory(new PropertyValueFactory<>("interest"));
		principalColumn.setCellValueFactory(new PropertyValueFactory<>("principal"));
		remainingColumn.setCellValueFactory(new PropertyValueFactory<>("remaining"));
		loanTable.setItems(loanList);
		loanValidField = new ValidPosDoubleField(loanField, loanSize, loanErrorOutline, -1, -1);
		termValidField = new ValidPosIntField(termField, loanTerm, termErrorOutline, -1, -1);
		interestValidField = new ValidPosDoubleField(interestField, interestRate, interestErrorOutline, -1, -1);
		filterFromValidField = new ValidPosIntField(filterMonthFromField, filterMonthFrom, monthFromErrorOutline, -1, -1);
		filterToValidField = new ValidPosIntField(filterMonthToField, filterMonthTo, monthToErrorOutline, -1, -1); 
		deferFromValidField = new ValidPosIntField(deferFromField, deferFrom, deferFromErrorOutline, -1, -1);
		deferAmountValidField = new ValidPosIntField(deferAmountField, deferAmount, deferAmountErrorOutline, -1, -1);
		deferRateValidField = new ValidPosDoubleField(deferRateField, deferRate, deferRateErrorOutline, -1, -1);
		loanField.setText(Double.toString(loanSize));
		termField.setText(Integer.toString(loanTerm));
		interestField.setText(Double.toString(interestRate));
		chartLoader = new FXMLLoader(getClass().getResource("/Chart.fxml"));
	}
	
	
	private boolean parseTextFields() {
		errorMsg.setVisible(false);
		loanErrorOutline.setVisible(false);
		termErrorOutline.setVisible(false);
		interestErrorOutline.setVisible(false);
		monthFromErrorOutline.setVisible(false);
		monthToErrorOutline.setVisible(false);
		saveAsTextErrorOutline.setVisible(false);
		deferFromErrorOutline.setVisible(false);
		deferAmountErrorOutline.setVisible(false);
		deferRateErrorOutline.setVisible(false);
		
		String errorText = "Error in field: ";
		boolean errorOccurred = false;
		
		try {
			loanSize = Float.parseFloat(loanField.getText());
			if (loanSize < 0) {
				NumberFormatException nfe = new NumberFormatException();
				throw nfe;
			}
		}
		catch (NumberFormatException nfe) {
			if (errorOccurred) {
				errorText += ", ";
			}
			errorText += "loan size";
			loanErrorOutline.setVisible(true);
			errorOccurred = true;
		}
		
		try {
			loanTerm = Integer.parseInt(termField.getText());
			if (loanTerm < 0) {
				NumberFormatException nfe = new NumberFormatException();
				throw nfe;
			}
		}
		catch (NumberFormatException nfe) {
			if (errorOccurred) {
				errorText += ", ";
			}
			errorText += "loan term";
			termErrorOutline.setVisible(true);
			errorOccurred = true;
		}
		
		try {
			interestRate = Float.parseFloat(interestField.getText());
			if (interestRate < 0) {
				NumberFormatException nfe = new NumberFormatException();
				throw nfe;
			}
		}
		catch (NumberFormatException nfe) {
			if (errorOccurred) {
				errorText += ", ";
			}
			errorText += "interest rate";
			interestErrorOutline.setVisible(true);
			errorOccurred = true;
		}
		
		if (!filterMonthFromField.getText().equals("")) {
			try {
				filterMonthFrom = Integer.parseInt(filterMonthFromField.getText());
				if (filterMonthFrom <= 0) {
					NumberFormatException nfe = new NumberFormatException();
					throw nfe;
				}
			}
			catch (NumberFormatException nfe) {
				if (errorOccurred) {
					errorText += ", ";
				}
				errorText += "month from";
				monthFromErrorOutline.setVisible(true);
				errorOccurred = true;
			}
		}
		else {
			filterMonthFrom = -1;
		}
		
		if (!filterMonthToField.getText().equals("")) {
			try {
				filterMonthTo = Integer.parseInt(filterMonthToField.getText());
				if ((filterMonthTo <= 0) || (filterMonthTo < filterMonthFrom)) {
					NumberFormatException nfe = new NumberFormatException();
					throw nfe;
				}
			}
			catch (NumberFormatException nfe) {
				if (errorOccurred) {
					errorText += ", ";
				}
				errorText += "month to";
				monthToErrorOutline.setVisible(true);
				errorOccurred = true;
			}
		}
		else {
			filterMonthTo = -1;
		}
		
		if (!deferFromField.getText().equals("")) {
			try {
				deferFrom = Integer.parseInt(deferFromField.getText());
				if (deferFrom < 0) {
					NumberFormatException nfe = new NumberFormatException();
					throw nfe;
				}
			}
			catch (NumberFormatException nfe) {
				if (errorOccurred) {
					errorText += ", ";
				}
				errorText += "defer from";
				deferFromErrorOutline.setVisible(true);
				errorOccurred = true;
			}
		}
		else {
			deferFrom = -1;
		}
		
		if (!deferAmountField.getText().equals("")) {
			try {
				deferAmount = Integer.parseInt(deferAmountField.getText());
				if (deferAmount < 0) {
					NumberFormatException nfe = new NumberFormatException();
					throw nfe;
				}
			}
			catch (NumberFormatException nfe) {
				if (errorOccurred) {
					errorText += ", ";
				}
				errorText += "defer amount";
				deferAmountErrorOutline.setVisible(true);
				errorOccurred = true;
			}
		}
		else {
			deferAmount = -1;
		}
		
		if (!deferRateField.getText().equals("")) {
			try {
				deferRate = Double.parseDouble(deferRateField.getText());
				if (deferRate < 0) {
					NumberFormatException nfe = new NumberFormatException();
					throw nfe;
				}
			}
			catch (NumberFormatException nfe) {
				if (errorOccurred) {
					errorText += ", ";
				}
				errorText += "defer rate";
				deferRateErrorOutline.setVisible(true);
				errorOccurred = true;
			}
		}
		else {
			deferRate = -1;
		}
			
		if (errorOccurred) {
			errorMsg.setText(errorText);
			errorMsg.setVisible(true);
		}
		
		return errorOccurred;
	}
	
	@FXML
	private void generate(ActionEvent event) throws IOException {
		boolean errorOccurred = parseTextFields();
		if (!errorOccurred) {
			int termLength = loanTerm;
			if (!termIsMonthly) {
				termLength *= 12;
			}
			boolean filterMonths = false;
			if ((filterMonthFrom != -1) && (filterMonthTo != -1)) {
				filterMonths = true;
			}
			boolean defer = false;
			if ((deferFrom != -1) && (deferAmount != -1) && (deferRate != -1)) {
				defer = true;
			}
			double deferScalarRate = deferRate / 1200;
			series = new Series<>(); 
			series.setName("loan\'s interest / time");
			loanList = FXCollections.observableArrayList();
			loanTable.setItems(loanList);
			double scalarMonthInterest = interestRate / 1200;
			System.out.print(interestRate);
			if (loanIsLinear) {
				double principal = loanSize / termLength;
				double remainingLoan = loanSize;
				for (int month = 1; month <= termLength; ++month) {
					if (defer && (month == deferFrom)) {
						termLength += deferAmount;
						int deferToMonth = deferFrom + deferAmount;
						for ( ; month < deferToMonth; ++month) {
							double deferInterest = remainingLoan * deferScalarRate;
							System.out.print(deferScalarRate);
							series.getData().add(new Data<Number, Number>(month, deferInterest));
							LoanStat loanStat = new LoanStat(month, deferInterest, 0, remainingLoan);
							if (filterMonths) {
								if ((month >= filterMonthFrom) && (month <= filterMonthTo)) {
									loanList.add(loanStat);
								}
							}
							else {
								loanList.add(loanStat);
							}
						}
					}
					double interest = Math.abs(remainingLoan) * scalarMonthInterest;
					remainingLoan -= principal;
					System.out.println("Adding to linear");
					series.getData().add(new Data<Number, Number>(month, interest));
					LoanStat loanStat = new LoanStat(month, interest, principal, remainingLoan);
					if (filterMonths) {
						if ((month >= filterMonthFrom) && (month <= filterMonthTo)) {
							loanList.add(loanStat);
						}
					}
					else {
						loanList.add(loanStat);
					}
				}
			}
			else {
				double term = Math.pow(scalarMonthInterest + 1, termLength);
				double annuityPrincipal = loanSize * scalarMonthInterest * term / (term - 1);
				//double totalAnnuityPayout = principal * termLength;
				double remainingLoan = loanSize;
				for (int month = 1; month <= termLength; ++month) {
					if (defer && (month == deferFrom)) {
						termLength += deferAmount;
						int deferToMonth = deferFrom + deferAmount;
						for ( ; month < deferToMonth; ++month) {
							double deferInterest = remainingLoan * deferScalarRate;
							System.out.print(deferScalarRate);
							series.getData().add(new Data<Number, Number>(month, deferInterest));
							LoanStat loanStat = new LoanStat(month, deferInterest, 0, remainingLoan);
							if (filterMonths) {
								if ((month >= filterMonthFrom) && (month <= filterMonthTo)) {
									loanList.add(loanStat);
								}
							}
							else {
								loanList.add(loanStat);
							}
						}
					}
					double interest = Math.abs(remainingLoan) * scalarMonthInterest;
					System.out.println("Adding to annuity");
					double principal = annuityPrincipal - interest;
					remainingLoan -= principal;
					series.getData().add(new Data<Number, Number>(month, interest));
					LoanStat loanStat = new LoanStat(month, interest, principal, remainingLoan);
					if (filterMonths) {
						if ((month >= filterMonthFrom) && (month <= filterMonthTo)) {
							loanList.add(loanStat);
						}
					}
					else {
						loanList.add(loanStat);
					}
				}
			}
		}
	}
	
	
	@FXML
	private void saveAsText() {
		if (loanList != null) {
			if (loanList.size() > 0) {
				errorMsg.setVisible(false);
				saveAsTextErrorOutline.setVisible(false);
				FileChooser fileChooser = new FileChooser();
				fileChooser.setTitle("Open a file to save loan calculation");
				File selectedFile = fileChooser.showOpenDialog(null);
				if (selectedFile != null) {
					try {
						BufferedWriter fileWriter = new BufferedWriter(new FileWriter(selectedFile));
						DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
						LocalDateTime now = LocalDateTime.now();
						String currentTime = dtf.format(now);
						fileWriter.write("Loan calculation on " + currentTime + "\n\n");
						fileWriter.write("Loan size: " + Double.toString(loanSize) + "\n\n");
						String loanTermType = "Monthly";
						if (!termIsMonthly) {
							loanTermType = "Yearly";
						}
						fileWriter.write(loanTermType + " loan term: " + Integer.toString(loanTerm) + "\n\n");
						fileWriter.write("Yearly interest rate (%): " + Double.toString(interestRate) + "\n\n");
						String loanType = "linear";
						if (!loanIsLinear) {
							loanType = "annuity";
						}
						fileWriter.write("Loan type: " + loanType + "\n\n");
						if ((filterMonthFrom != -1) && (filterMonthTo != -1)) {
							fileWriter.write("Filter month interval: "
											+ Integer.toString(filterMonthFrom)
											+ " - "
											+ Integer.toString(filterMonthTo)
											+ "\n\n"
							);
						}
						if ((deferFrom != -1) && (deferAmount != -1) && (deferRate != -1)) {
							fileWriter.write("Month deferred from: " + Integer.toString(deferFrom) + "\n\n");
							fileWriter.write("Defer amount: " + Integer.toString(deferAmount) + "\n\n");
							fileWriter.write("Defer yearly interest rate (%): " + Double.toString(deferRate) + "\n\n");
						}
						String columnNames = String.format(
								"%-20s%-20s%-20s%-20s",
								"Month", "Interest", "Principal", "Remaining"
						);
						fileWriter.write(columnNames + "\n");
						for (LoanStat loanStat: loanList) {
							String loanStats = String.format(
									"%-20d%-20.3f%-20.3f%-20.3f",
									loanStat.getMonth(),
									loanStat.getInterest(),
									loanStat.getPrincipal(),
									loanStat.getRemaining()
							);
							fileWriter.write(loanStats + "\n");
						}
						fileWriter.flush();
						fileWriter.close();
					}
					catch (IOException e) {
						e.printStackTrace();
					}		
				}
			}
			else {
				errorMsg.setText("Error: table is empty");
				saveAsTextErrorOutline.setVisible(true);
				errorMsg.setVisible(true);
			}
		}
		else {
			errorMsg.setText("Error: table is empty");
			saveAsTextErrorOutline.setVisible(true);
			errorMsg.setVisible(true);
		}
	}
	
	
	@FXML
	private void changeTermType() {
		termIsMonthly = rMonthlyButton.isSelected();
		System.out.println("termIsMonthly: " + termIsMonthly);
	}
	
	
	@FXML
	private void changeInterestType() {
		loanIsLinear = rLinearButton.isSelected();
		System.out.println("interestIsLinear: " + loanIsLinear);
	}
	

	@FXML
	private void seeChart(ActionEvent event) throws IOException {
		if (chartRoot == null) {
			chartRoot = chartLoader.load();
		}
		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
		Scene scene = new Scene(chartRoot);
		stage.setScene(scene);
	}
	
}
