package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart.Series;
import javafx.stage.Stage;

public class ChartController {
	
	@FXML
	private LineChart<Number, Number> loanChart;
	
	private Parent mainRoot;
	private Stage mainStage;
	private Scene mainScene;
	
	@FXML
	private void initialize() throws IOException {
		mainRoot = FXMLLoader.load(getClass().getResource("/Main.fxml"));
		mainScene = new Scene(mainRoot);
		if (MainController.series != null) {
			composeChart(MainController.series);
		}
	}
	
	
	@FXML
	private void switchToMainScene(ActionEvent event) {
		mainStage = (Stage) (((Node) event.getSource()).getScene().getWindow());
		mainStage.setScene(mainScene);
	}
	
	
	private void composeChart(Series<Number, Number> series) {
		loanChart.getData().add(series);
		if (MainController.loanIsLinear) {
			loanChart.setTitle("Linear loan chart");
		}
		else {
			loanChart.setTitle("Annuity loan chart");
		}
	}
	
	
}
