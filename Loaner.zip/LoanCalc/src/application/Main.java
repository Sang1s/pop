/**
@author Ignas Jogminas 4 gr.
*/

package application;
	
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;


public class Main extends Application {
	@Override
	public void start(Stage stage) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/Main.fxml"));
			Scene scene = new Scene(root, Color.LIGHTGRAY);
			//scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			Image icon = new Image("icon.png");
			stage.setResizable(false);
			stage.getIcons().add(icon);
			stage.setTitle("Loan calculator");
			stage.setScene(scene);
			stage.show();
			
			stage.setOnCloseRequest(event -> {
				event.consume();	
				logout(stage);
			});
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	private void logout(Stage stage) {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Exit");
		alert.setHeaderText("You're about to exit!");
		if (alert.showAndWait().get() == ButtonType.OK) {
			System.out.println("Exited");
			stage.close();
		}
	}
	
	
	public static void main(String[] args) {
		launch(args);
	}
}
