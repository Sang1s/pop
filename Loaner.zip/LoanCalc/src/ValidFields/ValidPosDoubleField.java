package ValidFields;

import javafx.scene.control.TextField;
import javafx.scene.shape.Rectangle;

public class ValidPosDoubleField extends ValidField<Double> {
	
	
	public ValidPosDoubleField(TextField textField, double fieldValue, Rectangle rect, double rectOffsetX, double rectOffsetY) {
		super(textField, fieldValue, rect, rectOffsetX, rectOffsetY);
	}
	
	
	@Override
	public Double parseField() throws NumberFormatException {
		Double parseResult = Double.parseDouble(textField.getText());
		if (parseResult < 0) {
			throw new NumberFormatException();
		}
		else {
			return parseResult;
		}
	}
	
}
