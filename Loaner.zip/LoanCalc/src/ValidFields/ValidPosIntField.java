package ValidFields;

import javafx.scene.control.TextField;
import javafx.scene.shape.Rectangle;

public class ValidPosIntField extends ValidField<Integer> {
	
	
	public ValidPosIntField(TextField textField, int fieldValue, Rectangle rect, double rectOffsetX, double rectOffsetY) {
		super(textField, fieldValue, rect, rectOffsetX, rectOffsetY);
	}
	
	@Override
	public Integer parseField() throws NumberFormatException {
		Integer parseResult = Integer.parseInt(textField.getText());
		if (parseResult < 0) {
			throw new NumberFormatException();
		}
		else {
			return parseResult;
		}
	}
	
}
