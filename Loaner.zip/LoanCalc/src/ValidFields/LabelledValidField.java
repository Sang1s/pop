package ValidFields;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.shape.Rectangle;

abstract public class LabelledValidField<T> extends ValidField<T> {
	
	protected Label label;
	// Offsets from textField
	double labelOffsetX;
	double labelOffsetY;

	
	public LabelledValidField(TextField textField, T fieldValue, Rectangle rect, double rectOffsetX, double rectOffsetY, Label label, double labelOffsetX, double labelOffsetY) {
		super(textField, fieldValue, rect, rectOffsetX, rectOffsetY);
		this.label = label;
	}
	
	
	@Override
	public void setLayoutX(double x) {
		super.setLayoutX(x);
		label.setLayoutX(x + labelOffsetX);
	}
	
	
	@Override
	public void setLayoutY(double y) {
		super.setLayoutY(y);
		label.setLayoutY(y + labelOffsetY);
	}
	
	
	public void setTitle(String title) {
		label.setText(title);
	}

}
