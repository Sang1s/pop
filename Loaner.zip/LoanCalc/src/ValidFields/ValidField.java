package ValidFields;

import javafx.scene.control.TextField;
import javafx.scene.shape.Rectangle;

abstract public class ValidField<T> {
	
	protected TextField textField;
	protected Rectangle rect;
	// Offsets from textField
	private double rectOffsetX;
	private double rectOffsetY; 
	protected T fieldValue;
	
	
	public ValidField(TextField textField, T fieldValue, Rectangle rect, double rectOffsetX, double rectOffsetY) {
		this.textField = textField;
		this.rect = rect;
		this.rectOffsetX = rectOffsetX;
		this.rectOffsetY = rectOffsetY;
		this.fieldValue = fieldValue;
	}
	
	
	public void setLayoutX(double x) {
		textField.setLayoutX(x);
		rect.setLayoutX(x + rectOffsetX);
	}
	
	
	public void setLayoutY(double y) {
		textField.setLayoutX(y);
		rect.setLayoutX(y + rectOffsetY);
	}
	
	
	public void setLayout(double x, double y) {
		setLayoutX(x);
		setLayoutY(y);
	}
	
	
	public NumberFormatException extraValidation() {
		return null;
	}
	
	
	public boolean validate(boolean wasError, String errorText, String errorMsg) {
		boolean errored = false;
		System.out.print("yo");
			try {
				System.out.print("yo");
				fieldValue = parseField();
				System.out.print("\n" + fieldValue.toString() + "\n");
				NumberFormatException nfe = extraValidation();
				if (nfe != null) {
					errored = true;
					throw nfe;
				}
			}
			catch (NumberFormatException nfe) {
				if (wasError) {
					errorText += ", ";
				}
				System.out.print("Hey");
				errorText += errorMsg;
				rect.setVisible(true);
			}
			return errored;
	}
	
	
	abstract public T parseField() throws NumberFormatException;
	
	
	public T getFieldValue() {
		return fieldValue;
	}
	
	
		
}
