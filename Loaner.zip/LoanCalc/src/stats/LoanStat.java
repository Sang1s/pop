package stats;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class LoanStat {
	
	private IntegerProperty month;
	private DoubleProperty interest;
	private DoubleProperty principal;
	private DoubleProperty remaining;
	
	
	public LoanStat(int month, double interest, double principal, double remaining) {
		this.month = new SimpleIntegerProperty(month);
		this.interest = new SimpleDoubleProperty(interest);
		this.principal = new SimpleDoubleProperty(principal);
		this.remaining = new SimpleDoubleProperty(remaining);
	}
	
	
	public int getMonth() {
		return this.month.get();
	}
	public void setMonth(int month) {
		this.month.set(month);
	}
	public IntegerProperty monthProperty() {
		return this.month;
	}
	
	public double getInterest() {
		return getDecimalPlaces(this.interest.get());
	}
	public void setInterest(double interest) {
		this.interest.set(interest);
	}
	public DoubleProperty interestProperty() {
		return this.interest;
	}
	
	public double getPrincipal() {
		return getDecimalPlaces(this.principal.get());
	}
	public void setMonth(double principal) {
		this.principal.set(principal);
	}
	public DoubleProperty principalProperty() {
		return this.principal;
	}
	
	public double getRemaining() {
		return getDecimalPlaces(this.remaining.get());
	}
	public void setRemaining(double remaining) {
		this.remaining.set(remaining);
	}
	public DoubleProperty remainingProperty() {
		return this.remaining;
	}
	
	
	private double getDecimalPlaces(double num) {
		return Math.round(num * 1000.0) / 1000.0;
	}
	
}
